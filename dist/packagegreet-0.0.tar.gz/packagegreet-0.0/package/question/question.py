def howareyou():
    print("How are you");