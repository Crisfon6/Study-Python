def greet_hello():
    print("hello from package")