from setuptools import setup

setup(
    name="packagegreet",
    version="0.0",
    description="Package of test",
    author="Crisfon6",
    author_email = "cdelgado376@unab.edu.co",
    packages=["package","package.question"]
)
