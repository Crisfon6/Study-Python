import setuptools

setuptools.setup(
    name="paqueteCalculos",
    version = "1.0.0",
    description = "paquete de suma",
    author ="Cristhian",
    author_email = "cdelgado376@unab.edu.co",
    url = "www.Github.com",
    packages =setuptools.find_packages(),

)